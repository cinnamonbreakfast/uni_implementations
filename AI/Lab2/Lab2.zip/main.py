from ui import UI

def main():
    uix = UI()
    uix.run()
    
    
    
main() 