from player_commands import Player
from gameplay import Gameplay
from board import Board


P = Player()
B = Board()
GP = Gameplay(P, B)
